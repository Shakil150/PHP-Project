
<html>

<head>
	<title>Customer Info</title>

</head>
<body>
<div class="name">
<h2>Customer Information Form</h2>
<br>
</div>


<div class="form1">
<form action="insert.php" method="post">
  Customer Id:<br>
  <input type="text" name="c_id" value=""><br>
  <br>
  Customer Name:<br>
  <input type="text" name="c_name" value=""><br>
  <br>
  Customer Contact:<br>
  <input type="text" name="c_contact" value=""><br><br>
<br>
   <input type="submit" value="Submit">
</form>


</div>
</body>

</html>

