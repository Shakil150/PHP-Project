<?php

     //$id=$_POST['id'];
     $c_id=$_POST['c_id'];
     $c_name=$_POST['c_name'];
	 $c_contact=$_POST['c_contact'];

      $pdo=new PDO ('mysql:host=localhost;dbname=c_information','root','');

        $query="INSERT INTO `c_info` (`id`, `c_id`, `c_name`,`c_contact`)
		VALUES (NULL, '$c_id', '$c_name','$c_contact')";
        if ($pdo->query($query)) {
			echo "<h2>Data Has been stored successfully!</h2>";
        }
//INSERT INTO `c_info` (`id`, `c_id`, `c_name`, `c_contact`) VALUES ('1', '001', 'sasdqa', '4563246');
	?>	
<form action="index.php" method="post">


		<input type="submit" value="Back To Previous Page">


</form>
